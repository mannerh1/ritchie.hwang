package com.example.sample1;

import android.app.Activity;
import android.os.Bundle;
import android.widget.ImageView;

public class FinalShow extends Activity {

	ImageView iv;
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.final_show_layout);
		
		iv = (ImageView) findViewById(R.id.final_show_imageview);
		
	}
	

}
