package com.example.sample1;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.URI;
import java.util.ArrayList;

import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.impl.client.DefaultHttpClient;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import android.app.Activity;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;

public class MainActivity extends Activity {

	
//	private Handler showImageHandler;
	ArrayList<String>showImages = new ArrayList<String>();
	private final int SHOW_IMAGE_MESSAGE = 5050;

	private final static String getURL = "https://api.instagram.com/v1/media/search?lat=48.858844&lng=2.294351&client_id=9b73012dab274cf19ba43aaa1ef9f8d3&q=selfie";

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);
	}
	
	@Override
	protected void onStart() {
		super.onStart();

		// get connection to instagram
		try {
			getInstagramData();
		} catch (IOException e) {
			e.printStackTrace();
		}
		// get the contents from them using tag of #selfie
		// parsing them
		// show them on the Android
	}
	private String getInstagramData() throws IOException {

		// using asynctask
		new getContentsFromInstagram().execute("");

		return null;
	}

	public class getContentsFromInstagram extends
			AsyncTask<String, Void, String> {

		@Override
		protected String doInBackground(String... params) {

			BufferedReader in = null;
			String returnValue = null;

			try {
				HttpClient client = new DefaultHttpClient();
				URI website = new URI(getURL);

				HttpGet request = new HttpGet();
				request.setURI(website);
				HttpResponse response = client.execute(request);

				HttpEntity hEntity = response.getEntity();
				InputStream iContent = hEntity.getContent();

				in = new BufferedReader(new InputStreamReader(iContent));
				StringBuffer sb = new StringBuffer();
				String l = "";
				String ln = System.getProperty("line.separator");
				while ((l = in.readLine()) != null) {
					sb.append(l + ln);
				}

				in.close();
				returnValue = sb.toString();

			} catch (IOException e) {
				e.printStackTrace();
			} catch (Exception e) {
				e.printStackTrace();
			}
			return returnValue;
		}

		@Override
		protected void onPostExecute(String result) {
			// super.onPostExecute(result);
//			Log.v("AAAAAAA", result);

			// parsing
			try {
				parsingContent(result);
			} catch (JSONException e) {
				e.printStackTrace();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}

	private void parsingContent(String getFeed) throws JSONException, IOException {

		JSONObject obj = new JSONObject(getFeed);

		JSONArray arr = obj.getJSONArray("data");
		for (int i = 0; i < arr.length(); i++) {

			JSONObject temp = arr.getJSONObject(i);
			String image = temp.getString("images");

			JSONObject temp2 = new JSONObject(image);
			String imageURL = temp2.getString("standard_resolution");
			
			// string processing
			String[] split = imageURL.split(",");
			String finalS = split[0].substring(8, split[0].length()-1);
			StringBuffer sb = new StringBuffer();
			for(int j=0; j<finalS.length();j++){
				if(finalS.charAt(j) != '\\')
					sb.append(finalS.charAt(j));
			}
			
			if (sb.toString().isEmpty() == false){

				// show image
//				addImage(sb.toString(), i);
				showImages.add(sb.toString());
//				Log.e("HHH", sb.toString());
			}
			// send the contents to other activity
			Intent intent =new Intent(this, ShowImages.class);
			intent.putStringArrayListExtra(String.valueOf(SHOW_IMAGE_MESSAGE), showImages);
			startActivityForResult(intent, SHOW_IMAGE_MESSAGE);
		}
		
	}


}
