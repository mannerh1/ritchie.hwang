package com.example.sample1;

import java.io.IOException;
import java.io.InputStream;
import java.net.URL;
import java.util.ArrayList;

import android.app.Activity;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.AsyncTask;
import android.os.Bundle;
import android.view.ViewGroup.LayoutParams;
import android.widget.ImageView;
import android.widget.LinearLayout;

public class ShowImages extends Activity {

	// String[] getURLs = null;
	ArrayList<String> getURLAddrs = new ArrayList<String>();
	private final int SHOW_IMAGE_MESSAGE = 5050;
	private LinearLayout changeArea;
	ArrayList<Bitmap> allBitmaps = new ArrayList<Bitmap>();

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);

		Bundle extra = getIntent().getExtras();
		getURLAddrs = extra.getStringArrayList(String
				.valueOf(SHOW_IMAGE_MESSAGE));

		changeArea = (LinearLayout) findViewById(R.id.change_area);

		// check
		for (int i = 0; i < getURLAddrs.size() - 1; i++) {
			new getImages().execute(getURLAddrs.get(i).toString());
		}

	}

	public class getImages extends AsyncTask<String, Void, Bitmap> {

		Bitmap bm;
		InputStream in;

		// String[] searchURLs;

		@Override
		protected Bitmap doInBackground(String... params) {

			try {
				in = (InputStream) new URL(params[0]).getContent();// .openStream();
				bm = BitmapFactory.decodeStream(in);

				allBitmaps.add(bm);

			} catch (IOException e) {
				e.printStackTrace();
			}
			return bm;
		}

	}

	private void makeViewPart() {

		// LinearLayout.LayoutParams layoutParams = null;

		for (int i = 0; i < allBitmaps.size() - 1; i++) {

			ImageView imageView = new ImageView(this);

			if (allBitmaps.get(i) != null)
				imageView.setImageBitmap(allBitmaps.get(i));

			changeArea.addView(imageView, new LayoutParams(
					LayoutParams.MATCH_PARENT, LayoutParams.WRAP_CONTENT

			));

			// ==============================================
			LinearLayout.LayoutParams params = null;
			params = (LinearLayout.LayoutParams) imageView.getLayoutParams();

			int rNum = i % 3;
			switch (rNum) {
			case 0:
				params.height = 600;
				params.width = 400;
				break;
			case 1:
				params.height = 300;
				params.width = 200;
				break;
			case 2:
				params.height = 300;
				params.width = 200;
				break;
			default:
				break;

			}

			imageView.setLayoutParams(params);
			
//			imageView.setOnClickListener(new View.OnClickListener() {
//				
//				@Override
//				public void onClick(View v) {
//					Intent it = new Intent(this, FinalShow.class);
//					Bundle extras = 
//					
//					it.putExtras(extras);
//					
//				}
//			});
		}
	}

	@Override
	protected void onStart() {
		super.onStart();

		makeViewPart();
	}
}
